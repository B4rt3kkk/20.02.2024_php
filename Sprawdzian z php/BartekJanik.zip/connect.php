<?php 

    $dbhost = "localhost";
    $username = "root";
    $password = "";
    $port = "3306";
    $database = "internetrzeczy";

    $conn = new mysqli($dbhost,$username,$password,$database,$port);

?>